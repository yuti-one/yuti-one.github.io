from os import system

print("Avvio installazione.")

system("pip install pyautogui")
system("pip3 install pyautogui")

print("\n\nInstallazione terminata.")
