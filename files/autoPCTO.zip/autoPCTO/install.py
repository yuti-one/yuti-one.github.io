from os import system

print("Avvio installazione di pyautogui.")

system("pip install pyautogui")

print("Avvio installazione di pillow.")

system("pip install Pillow")

print("\n\nInstallazione terminata.")
input()
