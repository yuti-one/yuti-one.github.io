import webbrowser as wb
import pyautogui as pag
from time import sleep
from pathlib import Path

# author: yuti-one.github.io

def main():

    # Verify if file exists
    f = Path("Rewatch.png")
    if not f.is_file():
        print("'Rewatch.png' not found")
        input("Press <ENTER> to continue")
        exit(1)

    # Main link
    link = "https://web.spaggiari.eu/col/app/default/corso.php?view=vid&video=01."

    # Set vars
    startFrom = int(input("Start from video number (1..25): "))
    j = 1
    i = startFrom

    width, height = pag.size()

    # Cycle for all videos 
    while i <= 25:
        # The numbers minor than 9 has to be written 02, 03, 06, 07
        if i <= 9:
            wb.open(link + "0" + str(i), new=0)

        # The video number 12 has 3 parts
        elif i == 12 and j <= 3:
            wb.open(link + "12" + ".0" + str(j), new=0 ) 
            j += 1
            i -= 1
            
        else:
            wb.open(link + str(i), new=0)

        sleep(7)

        pag.click(width/2, height/2)

        # Some displays are too tiny so the rewatch icon isn't visible
        pag.scroll(-10)
        
        # Wait until video ends
        print(f"Wait until video {i} ends...")
        
        print("...")
        # Until the rewatch icon isn't visible
        while pag.locateOnScreen("Rewatch.png") is None:
            sleep(5)
            continue
        
        print("Opening next video...")
        i += 1

if __name__ == "__main__":
    try:
        main()
    except Exception as errMsg:
        print(errMsg)
        input("Press <ENTER> to continue.")
